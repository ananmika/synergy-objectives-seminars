package com.synisis.objectives.iterator;

import java.util.function.Function;

/**
 * @author Astghik.Hakobyan
 * @since 9/26/2016.
 */
public interface Iterator<T> {

    Boolean hasNext();

    T next();

    void apply(Function<T,T> function);

}
