package com.synisis.objectives.iterator;

/**
 * @author Astghik.Hakobyan
 * @since 9/26/2016.
 */
public class IteratorDemo {

    public static void main(String[] args) {
        AggregateObject<Integer> integers = new AggregateObject<>();
        integers.addObject(5);
        integers.addObject(4);
        integers.addObject(3);
        Iterator<Integer> iteratorFromBeginning = integers.iteratorFactory.getIterator(TraversalAlgorithm.FromBeginning);
        Iterator<Integer> iteratorFromEnd = integers.iteratorFactory.getIterator(TraversalAlgorithm.FromEnd);
        while(iteratorFromBeginning.hasNext()) {
            System.out.print(iteratorFromBeginning.next());
        }
        System.out.println("\n");
        while(iteratorFromEnd.hasNext()) {
            System.out.print(iteratorFromEnd.next());
        }
        iteratorFromBeginning.apply((Integer a) -> ++a);
    }
}
