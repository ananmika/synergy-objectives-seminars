package com.synisis.objectives.iterator;

/**
 * @author Astghik.Hakobyan
 * @since 9/26/2016.
 */
public enum TraversalAlgorithm {

    FromBeginning("FromBeginning"),
    FromEnd("FromEnd");

    TraversalAlgorithm(String algorithmName) {
        this.algorithmName = algorithmName;
    }

    private String algorithmName;
}
