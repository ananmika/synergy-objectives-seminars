package com.synisis.objectives.iterator;

import java.util.ArrayList;
import java.util.function.Function;

/**
 * @author Astghik.Hakobyan
 * @since 9/26/2016.
 */
public class AggregateObject<T> {

    private ArrayList<T> objects;

    public IteratorFactory iteratorFactory;

    AggregateObject() {
        objects = new ArrayList<>();
        iteratorFactory = new IteratorFactory();
    }

    public void addObject(T object) {
        objects.add(object);
    }

    private abstract class DefaultIterator implements Iterator<T> {

        protected Integer index;

        public Boolean hasNext() {
            return index >= 0 && index < objects.size();
        }


        public void apply(Function<T, T> function) {
            for (int i = 0; i < objects.size(); i++) {
                System.out.println(function.apply(objects.get(i)));
            }
        }
    }

    private class IteratorTraversingFromBeginning extends DefaultIterator {

        IteratorTraversingFromBeginning() {
            index = 0;
        }

        @Override
        public T next() {
            return objects.get(index++);
        }
    }

    private class IteratorTraversingFromEnd extends DefaultIterator {

        IteratorTraversingFromEnd() {
            index = objects.size() - 1;
        }

        @Override
        public T next() {
            return objects.get(index--);
        }
    }

    public class IteratorFactory {

        Iterator<T> getIterator(TraversalAlgorithm traversalAlgorithm) {
            switch (traversalAlgorithm) {
                case FromBeginning:
                    return new IteratorTraversingFromBeginning();
                case FromEnd:
                    return new IteratorTraversingFromEnd();
            }
            return null;
        }

    }


}
